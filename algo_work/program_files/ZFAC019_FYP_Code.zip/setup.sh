#!/bin/bash
pip3 install -r requirements.txt
python3 main.py UK2017_votes UK2017_probs 9 326
